// ============================================================
//  CONFIGURA AQUÍ TU PROYECTO DE FIREBASE
// ------------------------------------------------------------
//  1. Ve a https://console.firebase.google.com
//  2. Crea un proyecto -> Configuración -> "Tus apps" -> Web
//  3. Copia el objeto firebaseConfig y pégalo abajo.
//  4. Activa Authentication -> Sign-in method -> Google.
//  5. Activa Realtime Database (RTDB) y añade tu dominio a
//     los dominios autorizados en Authentication -> Settings.
// ============================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getDatabase,
  ref,
  set,
  get,
  push,
  update,
  remove,
  onValue,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

export const firebaseConfig = {
  apiKey: "AIzaSyBjTk1YD_CRBLA2DzNAjcCYZZeGktY7pZM",
  authDomain: "netorbemusic.firebaseapp.com",
  databaseURL: "https://netorbemusic-default-rtdb.firebaseio.com",
  projectId: "netorbemusic",
  storageBucket: "netorbemusic.firebasestorage.app",
  messagingSenderId: "657010160263",
  appId: "1:657010160263:web:5e96c38c337014f9827e22",
  measurementId: "G-QTRHPY6LF2"
};

export const firebaseReady =
  firebaseConfig.apiKey && firebaseConfig.apiKey !== "TU_API_KEY";

let app, auth, db, googleProvider;

if (firebaseReady) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getDatabase(app);
  googleProvider = new GoogleAuthProvider();
}

export {
  app,
  auth,
  db,
  googleProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  ref,
  set,
  get,
  push,
  update,
  remove,
  onValue,
};
