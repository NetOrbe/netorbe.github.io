import http.server
import socketserver
import urllib.parse
import json
import time
import yt_dlp
import requests
import threading
import sys
import os
from ytmusicapi import YTMusic

# --- Configuración ---
PORT = 3000
FIREBASE_URL = "https://netorbemusic-default-rtdb.firebaseio.com"
STATIC_DIR = "public"
MAX_AGE = 7200
REGEN_WINDOW = 600
TIMESTAMP_THRESHOLD = 1600000000 

if not os.path.exists(STATIC_DIR):
    os.makedirs(STATIC_DIR)

ytmusic = YTMusic()
session = requests.Session()

# --- Funciones Auxiliares ---
def get_audio_data(vid_id):
    """Extrae info fresca y formato solicitado"""
    with yt_dlp.YoutubeDL({'quiet': True, 'format': 'bestaudio', 'skip_download': True}) as ydl:
        info = ydl.extract_info(f"https://www.youtube.com/watch?v={vid_id}", download=False)
        return {
            "videoid": vid_id,
            "nombre": info.get('title'),
            "artista": info.get('uploader'),
            "imagen": info.get('thumbnail'),
            "url": info.get('url'),
            "timestamp": time.time()
        }

def cache_worker():
    print("[Worker] Monitoreo de caché activo...")
    while True:
        try:
            resp = session.get(f"{FIREBASE_URL}/curls-v2.json")
            data = resp.json() or {}
            now = time.time()
            for vid_id, info in data.items():
                ts = info.get('timestamp', 0)
                age = now - ts
                if ts < TIMESTAMP_THRESHOLD or age >= MAX_AGE or (MAX_AGE - age) <= REGEN_WINDOW:
                    new_data = get_audio_data(vid_id)
                    session.put(f"{FIREBASE_URL}/curls-v2/{vid_id}.json", json=new_data)
        except Exception as e:
            print(f"[Worker Error] {e}")
        time.sleep(5)

# --- Servidor ---
class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=STATIC_DIR, **kwargs)

    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode('utf-8'))

    def do_GET(self):
        parsed_url = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed_url.query)

        # 1. Redirección raíz
        if parsed_url.path == '/':
            self.path = '/main.html'
            return super().do_GET()

        # 2. Búsqueda
        if parsed_url.path == '/api/search':
            query = params.get('q', [''])[0]
            res = ytmusic.search(query, filter="songs")
            formatted = [{
                "videoid": r['videoId'],
                "nombre": r['title'],
                "artista": r['artists'][0]['name'] if r['artists'] else 'N/A',
                "imagen": r['thumbnails'][-1]['url']
            } for r in res]
            return self._send_json(formatted)

        # 3. Obtener URL de reproducción
        if parsed_url.path == '/api/get-play':
            vid_id = params.get('id', [None])[0]
            if not vid_id: return self.send_error(400)
            
            data = session.get(f"{FIREBASE_URL}/curls-v2/{vid_id}.json").json()
            if data and data.get('timestamp', 0) > TIMESTAMP_THRESHOLD:
                return self._send_json({"url": data['url']})
            else:
                new_data = get_audio_data(vid_id)
                session.put(f"{FIREBASE_URL}/curls-v2/{vid_id}.json", json=new_data)
                return self._send_json({"url": new_data['url']})

        # 4. Archivos estáticos
        return super().do_GET()

# --- Ejecución ---
threading.Thread(target=cache_worker, daemon=True).start()

try:
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"Servidor iniciado en http://localhost:{PORT}")
        httpd.serve_forever()
except KeyboardInterrupt:
    print("\n[Cierre] Limpiando base de datos...")
    session.delete(f"{FIREBASE_URL}/curls-v2.json")
    print("[Cierre] Nodo curls-v2 eliminado.")
    sys.exit(0)
    