import {
  firebaseReady,
  auth,
  db,
  googleProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  ref,
  set,
  get,
  push,
  remove,
  onValue,
} from "/firebase-config.js";

/* ============================================================
   Config & helpers
   ============================================================ */
const API = ""; // same server -> use relative "/api/..."
const ALBUM_PH = "/album-ph.png";
const PH = "/ph.png";

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];

const el = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
};

const fmtTime = (s) => {
  if (!s || isNaN(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60).toString().padStart(2, "0");
  return `${m}:${sec}`;
};

const escapeHtml = (str = "") =>
  str.replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

let toastTimer;
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add("hidden"), 2600);
}

/* Simple in-memory cache for stream urls */
const urlCache = new Map();

async function apiSearch(q, r = 20) {
  const res = await fetch(`${API}/api/search?q=${encodeURIComponent(q)}&r=${r}`);
  if (!res.ok) throw new Error("search failed");
  return res.json();
}

async function apiGetPlay(id) {
  if (urlCache.has(id)) return urlCache.get(id);
  const res = await fetch(`${API}/api/get-play?id=${encodeURIComponent(id)}`);
  if (!res.ok) throw new Error("get-play failed");
  const data = await res.json();
  if (data && data.url) urlCache.set(id, data.url);
  return data.url;
}

/* ============================================================
   Global state
   ============================================================ */
const state = {
  user: null,
  playlists: {},      // id -> {name, cover, tracks:{}}
  recents: [],        // recent tracks array
  queue: [],          // current queue (artist songs)
  queueIndex: -1,
  current: null,      // current track
  isPlaying: false,
  preloadedId: null,
};

const audio = $("#audio");
const preloadAudio = $("#preloadAudio");

/* ============================================================
   Auth
   ============================================================ */
function renderAuth() {
  const slot = $("#authSlot");
  slot.innerHTML = "";
  if (state.user) {
    const btn = el("button", "avatar-btn");
    const img = el("img");
    img.src = state.user.photoURL || PH;
    img.alt = "";
    img.referrerPolicy = "no-referrer";
    btn.appendChild(img);
    btn.appendChild(el("span", null, escapeHtml(state.user.displayName || "Usuario")));
    btn.onclick = () => {
      if (confirm("¿Cerrar sesión?")) doSignOut();
    };
    slot.appendChild(btn);
  } else {
    const btn = el("button", "btn-google");
    btn.innerHTML = `<img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt=""/> Entrar con Google`;
    btn.onclick = doSignIn;
    slot.appendChild(btn);
  }
}

async function doSignIn() {
  if (!firebaseReady) {
    toast("Configura Firebase en firebase-config.js");
    return;
  }
  try {
    await signInWithPopup(auth, googleProvider);
  } catch (e) {
    toast("No se pudo iniciar sesión");
    console.log("[v0] signin error", e.message);
  }
}

async function doSignOut() {
  try {
    await signOut(auth);
  } catch (e) {
    console.log("[v0] signout error", e.message);
  }
}

function initAuth() {
  if (!firebaseReady) {
    renderAuth();
    return;
  }
  onAuthStateChanged(auth, (user) => {
    state.user = user;
    renderAuth();
    if (user) {
      subscribePlaylists();
      subscribeRecents();
    } else {
      state.playlists = {};
      state.recents = [];
      renderSidePlaylists();
      if (location.hash.startsWith("#/library") || location.hash.startsWith("#/playlist")) {
        router();
      }
    }
  });
}

/* ============================================================
   Firebase data: playlists + recents
   ============================================================ */
function uid() {
  return state.user ? state.user.uid : null;
}

function subscribePlaylists() {
  if (!firebaseReady || !uid()) return;
  onValue(ref(db, `users/${uid()}/playlists`), (snap) => {
    state.playlists = snap.val() || {};
    renderSidePlaylists();
    const h = location.hash;
    if (h.startsWith("#/library") || h.startsWith("#/playlist")) router();
  });
}

function subscribeRecents() {
  if (!firebaseReady || !uid()) return;
  onValue(ref(db, `users/${uid()}/recents`), (snap) => {
    const val = snap.val() || {};
    state.recents = Object.values(val)
      .sort((a, b) => (b.playedAt || 0) - (a.playedAt || 0))
      .slice(0, 30);
    if (location.hash === "" || location.hash.startsWith("#/home")) router();
  });
}

async function saveRecent(track) {
  if (!firebaseReady || !uid()) return;
  try {
    await set(ref(db, `users/${uid()}/recents/${track.videoid}`), {
      ...track,
      playedAt: Date.now(),
    });
  } catch (e) {
    console.log("[v0] saveRecent error", e.message);
  }
}

async function createPlaylist(name) {
  if (!firebaseReady || !uid()) {
    toast("Inicia sesión para crear playlists");
    return null;
  }
  const listRef = push(ref(db, `users/${uid()}/playlists`));
  await set(listRef, { name, cover: "", createdAt: Date.now(), tracks: {} });
  toast(`Playlist "${name}" creada`);
  return listRef.key;
}

async function deletePlaylist(id) {
  if (!firebaseReady || !uid()) return;
  await remove(ref(db, `users/${uid()}/playlists/${id}`));
  toast("Playlist eliminada");
  location.hash = "#/library";
}

async function addTrackToPlaylist(id, track) {
  if (!firebaseReady || !uid()) {
    toast("Inicia sesión primero");
    return;
  }
  const pl = state.playlists[id];
  const cover = pl && pl.cover ? pl.cover : track.imagen || "";
  await set(ref(db, `users/${uid()}/playlists/${id}/tracks/${track.videoid}`), {
    ...track,
    addedAt: Date.now(),
  });
  if (pl && !pl.cover && cover) {
    await set(ref(db, `users/${uid()}/playlists/${id}/cover`), cover);
  }
  toast("Añadida a la playlist");
}

async function removeTrackFromPlaylist(id, videoid) {
  if (!firebaseReady || !uid()) return;
  await remove(ref(db, `users/${uid()}/playlists/${id}/tracks/${videoid}`));
  toast("Eliminada de la playlist");
}

function playlistTracks(pl) {
  if (!pl || !pl.tracks) return [];
  return Object.values(pl.tracks).sort((a, b) => (a.addedAt || 0) - (b.addedAt || 0));
}

/* ============================================================
   Player
   ============================================================ */
async function playTrack(track, queue, index) {
  state.current = track;
  if (queue) {
    state.queue = queue;
    state.queueIndex = index != null ? index : queue.findIndex((t) => t.videoid === track.videoid);
  }
  updatePlayerUI();
  showMiniPlayer();

  try {
    const url = await apiGetPlay(track.videoid);
    if (!url) throw new Error("no url");
    // Only set if still the current track (avoid race)
    if (state.current && state.current.videoid === track.videoid) {
      audio.src = url;
      await audio.play();
      state.isPlaying = true;
      updatePlayButtons();
      saveRecent(track);
      setMediaSession(track);
      // Build artist queue if this play started outside a proper queue
      ensureArtistQueue(track);
      preloadNext();
    }
  } catch (e) {
    console.log("[v0] play error", e.message);
    toast("No se pudo reproducir la canción");
  }
}

/* When user plays a song from the searcher, the "next" songs must be
   songs from the ARTIST, not from the search results list. */
async function ensureArtistQueue(track) {
  // If queue already contains this track and has following songs, keep it
  const idx = state.queue.findIndex((t) => t.videoid === track.videoid);
  const hasFollowing = idx >= 0 && idx < state.queue.length - 1;
  if (state.queue.__artist === track.artista && hasFollowing) {
    state.queueIndex = idx;
    return;
  }
  try {
    const results = await apiSearch(track.artista, 25);
    let songs = results.filter((s) => s.videoid);
    // ensure the current track is first
    songs = songs.filter((s) => s.videoid !== track.videoid);
    const queue = [track, ...songs];
    queue.__artist = track.artista;
    state.queue = queue;
    state.queueIndex = 0;
    renderFullQueue();
    preloadNext();
  } catch (e) {
    console.log("[v0] artist queue error", e.message);
  }
}

function togglePlay() {
  if (!state.current) return;
  if (audio.paused) {
    audio.play();
    state.isPlaying = true;
  } else {
    audio.pause();
    state.isPlaying = false;
  }
  updatePlayButtons();
}

function nextTrack() {
  if (!state.queue.length) return;
  let next = state.queueIndex + 1;
  if (next >= state.queue.length) next = 0;
  state.queueIndex = next;
  playTrack(state.queue[next], state.queue, next);
}

function prevTrack() {
  if (!state.queue.length) return;
  if (audio.currentTime > 3) {
    audio.currentTime = 0;
    return;
  }
  let prev = state.queueIndex - 1;
  if (prev < 0) prev = state.queue.length - 1;
  state.queueIndex = prev;
  playTrack(state.queue[prev], state.queue, prev);
}

/* Preload the NEXT song's stream URL so it starts instantly */
async function preloadNext() {
  if (!state.queue.length) return;
  const nextIdx = state.queueIndex + 1 < state.queue.length ? state.queueIndex + 1 : 0;
  const nextTrackObj = state.queue[nextIdx];
  if (!nextTrackObj || state.preloadedId === nextTrackObj.videoid) return;
  try {
    const url = await apiGetPlay(nextTrackObj.videoid);
    if (url) {
      state.preloadedId = nextTrackObj.videoid;
      preloadAudio.src = url; // warms the connection / buffer
      console.log("[v0] preloaded next:", nextTrackObj.nombre);
    }
  } catch (e) {
    console.log("[v0] preload error", e.message);
  }
}

/* ---- Player UI ---- */
const playIcon = `<svg viewBox="0 0 24 24" class="ic"><path d="M6 4l14 8-14 8V4z"/></svg>`;
const pauseIcon = `<svg viewBox="0 0 24 24" class="ic"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>`;

function updatePlayButtons() {
  const icon = state.isPlaying ? pauseIcon : playIcon;
  $("#mpPlay").innerHTML = icon;
  $("#fpPlay").innerHTML = icon;
  markPlayingRows();
  if ("mediaSession" in navigator) {
    navigator.mediaSession.playbackState = state.isPlaying ? "playing" : "paused";
  }
}

function updatePlayerUI() {
  const t = state.current;
  if (!t) return;
  $("#mpArt").src = t.imagen || ALBUM_PH;
  $("#mpTitle").textContent = t.nombre || "—";
  $("#mpArtist").textContent = t.artista || "—";
  $("#fpArt").src = t.imagen || ALBUM_PH;
  $("#fpTitle").textContent = t.nombre || "—";
  $("#fpArtist").textContent = t.artista || "—";
  $("#fpBg").style.backgroundImage = `url("${t.imagen || ALBUM_PH}")`;
  renderFullQueue();
}

function showMiniPlayer() {
  $("#miniPlayer").classList.remove("hidden");
}

function markPlayingRows() {
  $$(".track-row").forEach((row) => {
    row.classList.toggle(
      "playing",
      state.current && row.dataset.vid === state.current.videoid
    );
  });
}

function renderFullQueue() {
  const box = $("#fpQueue");
  box.innerHTML = "";
  const upcoming = state.queue.slice(state.queueIndex + 1);
  if (!upcoming.length) {
    box.appendChild(el("div", "empty", "No hay más canciones en la cola."));
    return;
  }
  upcoming.forEach((t) => {
    const row = trackRow(t, null, {
      onPlay: () => {
        const idx = state.queue.findIndex((x) => x.videoid === t.videoid);
        playTrack(t, state.queue, idx);
      },
      compact: true,
    });
    box.appendChild(row);
  });
}

/* ---- audio events ---- */
audio.addEventListener("timeupdate", () => {
  const pct = audio.duration ? (audio.currentTime / audio.duration) * 100 : 0;
  $("#mpProgressFill").style.width = pct + "%";
  const seek = $("#fpSeek");
  if (!seek.dragging) seek.value = pct;
  $("#fpCur").textContent = fmtTime(audio.currentTime);
  $("#fpDur").textContent = fmtTime(audio.duration);
  updatePositionState();
});
audio.addEventListener("ended", nextTrack);
audio.addEventListener("play", () => {
  state.isPlaying = true;
  updatePlayButtons();
});
audio.addEventListener("pause", () => {
  state.isPlaying = false;
  updatePlayButtons();
});

/* ============================================================
   Media Session API
   ============================================================ */
function setMediaSession(track) {
  if (!("mediaSession" in navigator)) return;
  navigator.mediaSession.metadata = new MediaMetadata({
    title: track.nombre || "",
    artist: track.artista || "",
    album: "Netorbe Music",
    artwork: [
      { src: track.imagen || ALBUM_PH, sizes: "96x96", type: "image/png" },
      { src: track.imagen || ALBUM_PH, sizes: "512x512", type: "image/png" },
    ],
  });
  navigator.mediaSession.setActionHandler("play", () => togglePlay());
  navigator.mediaSession.setActionHandler("pause", () => togglePlay());
  navigator.mediaSession.setActionHandler("previoustrack", () => prevTrack());
  navigator.mediaSession.setActionHandler("nexttrack", () => nextTrack());
  navigator.mediaSession.setActionHandler("seekto", (d) => {
    if (d.seekTime != null) audio.currentTime = d.seekTime;
  });
}

function updatePositionState() {
  if (!("mediaSession" in navigator) || !audio.duration) return;
  try {
    navigator.mediaSession.setPositionState({
      duration: audio.duration,
      playbackRate: audio.playbackRate,
      position: audio.currentTime,
    });
  } catch {}
}

/* ============================================================
   Components: track row / cards
   ============================================================ */
function trackRow(track, index, opts = {}) {
  const row = el("div", "track-row");
  row.dataset.vid = track.videoid;

  if (!opts.compact) {
    row.appendChild(el("div", "tr-index", index != null ? String(index + 1) : ""));
  } else {
    row.appendChild(el("div", "tr-index", ""));
  }

  const art = el("img", "tr-art");
  art.src = track.imagen || ALBUM_PH;
  art.alt = "";
  art.loading = "lazy";
  row.appendChild(art);

  const main = el("div", "tr-main");
  main.appendChild(el("div", "tr-title", escapeHtml(track.nombre || "")));
  main.appendChild(el("div", "tr-artist", escapeHtml(track.artista || "")));
  row.appendChild(main);

  const actions = el("div", "tr-actions");
  const addBtn = el(
    "button",
    "icon-btn",
    `<svg viewBox="0 0 24 24" class="ic"><path d="M12 5v14"/><path d="M5 12h14"/></svg>`
  );
  addBtn.title = "Añadir a playlist";
  addBtn.onclick = (e) => {
    e.stopPropagation();
    openPlaylistPicker(track);
  };
  actions.appendChild(addBtn);

  if (opts.onRemove) {
    const rm = el(
      "button",
      "icon-btn",
      `<svg viewBox="0 0 24 24" class="ic"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 14h10l1-14"/></svg>`
    );
    rm.title = "Quitar";
    rm.onclick = (e) => {
      e.stopPropagation();
      opts.onRemove();
    };
    actions.appendChild(rm);
  }
  row.appendChild(actions);

  row.onclick = () => {
    if (opts.onPlay) opts.onPlay();
  };
  return row;
}

function artistCard(track) {
  const card = el("button", "card");
  const art = el("img", "card-art");
  art.src = track.imagen || ALBUM_PH;
  art.alt = "";
  art.loading = "lazy";
  card.appendChild(art);
  card.appendChild(el("div", "card-title", escapeHtml(track.nombre || "")));
  card.appendChild(el("div", "card-sub", escapeHtml(track.artista || "")));
  const play = el("div", "card-play", playIcon);
  card.appendChild(play);
  card.onclick = () => playTrack(track, null);
  return card;
}

/* ============================================================
   Views / Router
   ============================================================ */
const view = $("#view");

function setActiveNav(route) {
  $$("[data-route]").forEach((n) =>
    n.classList.toggle("active", n.dataset.route === route)
  );
}

async function router() {
  const hash = location.hash || "#/home";
  const [path, param] = hash.replace(/^#\//, "").split("/");

  if (path === "" || path === "home") {
    setActiveNav("home");
    renderHome();
  } else if (path === "search") {
    setActiveNav("search");
    renderSearch(decodeURIComponent(param || ""));
  } else if (path === "library") {
    setActiveNav("library");
    renderLibrary();
  } else if (path === "playlist") {
    setActiveNav("library");
    renderPlaylist(param);
  } else {
    renderHome();
  }
}

function renderHome() {
  view.innerHTML = "";
  view.appendChild(el("h1", "page-title", "Buenas 👋"));

  // Recents
  const recSection = el("section", "section");
  const head = el("div", "section-head");
  head.appendChild(el("div", "section-title", "Escuchado recientemente"));
  recSection.appendChild(head);

  if (!state.user) {
    recSection.appendChild(
      el("div", "empty", "Inicia sesión con Google para guardar y ver tu historial.")
    );
  } else if (!state.recents.length) {
    recSection.appendChild(
      el("div", "empty", "Aún no has escuchado nada. ¡Busca una canción!")
    );
  } else {
    const grid = el("div", "card-grid");
    state.recents.slice(0, 12).forEach((t) => grid.appendChild(artistCard(t)));
    recSection.appendChild(grid);
  }
  view.appendChild(recSection);

  // Suggestions to explore
  const explore = el("section", "section");
  const eh = el("div", "section-head");
  eh.appendChild(el("div", "section-title", "Explorar"));
  explore.appendChild(eh);
  const chips = el("div", "chip-row");
  ["Bad Bunny", "Taylor Swift", "The Weeknd", "Karol G", "Coldplay", "Feid", "Dua Lipa"].forEach(
    (name) => {
      const c = el("button", "chip", name);
      c.onclick = () => (location.hash = `#/search/${encodeURIComponent(name)}`);
      chips.appendChild(c);
    }
  );
  explore.appendChild(chips);
  view.appendChild(explore);
}

let searchTimer;
async function renderSearch(query) {
  view.innerHTML = "";
  view.appendChild(el("h1", "page-title", "Buscar"));

  if (!query) {
    view.appendChild(
      el("div", "empty", "Escribe el nombre de un artista o canción arriba.")
    );
    return;
  }

  const loading = el("div", "loading", "Buscando…");
  view.appendChild(loading);

  try {
    const results = await apiSearch(query, 25);
    loading.remove();
    const songs = results.filter((s) => s.videoid);
    if (!songs.length) {
      view.appendChild(el("div", "empty", "Sin resultados."));
      return;
    }
    const sec = el("section", "section");
    const head = el("div", "section-head");
    head.appendChild(el("div", "section-title", `Resultados para “${escapeHtml(query)}”`));
    sec.appendChild(head);
    const list = el("div", "track-list");
    songs.forEach((t, i) => {
      const row = trackRow(t, i, {
        onPlay: () => playTrack(t, null), // queue becomes the ARTIST's songs
      });
      list.appendChild(row);
    });
    sec.appendChild(list);
    view.appendChild(sec);
    markPlayingRows();
  } catch (e) {
    loading.remove();
    view.appendChild(el("div", "empty", "Error al buscar. Inténtalo de nuevo."));
    console.log("[v0] search error", e.message);
  }
}

function renderLibrary() {
  view.innerHTML = "";
  const head = el("div", "section-head");
  head.appendChild(el("h1", "page-title", "Tu biblioteca"));
  const newBtn = el(
    "button",
    "icon-btn",
    `<svg viewBox="0 0 24 24" class="ic"><path d="M12 5v14"/><path d="M5 12h14"/></svg>`
  );
  newBtn.title = "Nueva playlist";
  newBtn.onclick = openCreatePlaylist;
  head.appendChild(newBtn);
  view.appendChild(head);

  if (!state.user) {
    view.appendChild(el("div", "empty", "Inicia sesión para ver tus playlists."));
    return;
  }

  const ids = Object.keys(state.playlists);
  if (!ids.length) {
    view.appendChild(el("div", "empty", "No tienes playlists todavía. Crea una con el botón +."));
    return;
  }

  const grid = el("div", "card-grid");
  ids.forEach((id) => {
    const pl = state.playlists[id];
    const card = el("button", "card");
    const art = el("img", "card-art");
    art.src = pl.cover || ALBUM_PH;
    art.alt = "";
    card.appendChild(art);
    card.appendChild(el("div", "card-title", escapeHtml(pl.name || "Playlist")));
    const count = pl.tracks ? Object.keys(pl.tracks).length : 0;
    card.appendChild(el("div", "card-sub", `${count} canción${count === 1 ? "" : "es"}`));
    card.onclick = () => (location.hash = `#/playlist/${id}`);
    grid.appendChild(card);
  });
  view.appendChild(grid);
}

function renderPlaylist(id) {
  const pl = state.playlists[id];
  view.innerHTML = "";
  if (!pl) {
    view.appendChild(el("div", "empty", "Playlist no encontrada."));
    return;
  }
  const tracks = playlistTracks(pl);

  const header = el("div", "pl-header");
  const cover = el("img", "pl-cover");
  cover.src = pl.cover || ALBUM_PH;
  cover.alt = "";
  header.appendChild(cover);
  const info = el("div");
  info.appendChild(el("div", "pl-kind", "Playlist"));
  info.appendChild(el("div", "pl-name", escapeHtml(pl.name || "Playlist")));
  info.appendChild(
    el("div", "pl-meta", `${tracks.length} canción${tracks.length === 1 ? "" : "es"}`)
  );
  header.appendChild(info);
  view.appendChild(header);

  const actions = el("div");
  actions.style.display = "flex";
  actions.style.alignItems = "center";
  actions.style.gap = "16px";
  const playAll = el("button", "play-lg", playIcon);
  playAll.onclick = () => {
    if (tracks.length) playTrack(tracks[0], tracks, 0);
  };
  actions.appendChild(playAll);
  const del = el(
    "button",
    "icon-btn",
    `<svg viewBox="0 0 24 24" class="ic"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 14h10l1-14"/></svg>`
  );
  del.title = "Eliminar playlist";
  del.onclick = () => {
    if (confirm(`¿Eliminar la playlist "${pl.name}"?`)) deletePlaylist(id);
  };
  actions.appendChild(del);
  view.appendChild(actions);

  if (!tracks.length) {
    view.appendChild(el("div", "empty", "Esta playlist está vacía. Añade canciones desde el buscador."));
    return;
  }

  const list = el("div", "track-list");
  tracks.forEach((t, i) => {
    const row = trackRow(t, i, {
      onPlay: () => playTrack(t, tracks, i),
      onRemove: () => removeTrackFromPlaylist(id, t.videoid),
    });
    list.appendChild(row);
  });
  view.appendChild(list);
  markPlayingRows();
}

function renderSidePlaylists() {
  const box = $("#sidePlaylists");
  if (!box) return;
  box.innerHTML = "";
  if (!state.user) return;
  Object.keys(state.playlists).forEach((id) => {
    const pl = state.playlists[id];
    const b = el("button", "side-pl");
    const img = el("img");
    img.src = pl.cover || ALBUM_PH;
    img.alt = "";
    b.appendChild(img);
    b.appendChild(el("span", null, escapeHtml(pl.name || "Playlist")));
    b.onclick = () => (location.hash = `#/playlist/${id}`);
    box.appendChild(b);
  });
}

/* ============================================================
   Modals
   ============================================================ */
function openModal(cardHtmlBuilder) {
  const modal = $("#modal");
  const card = $("#modalCard");
  card.innerHTML = "";
  cardHtmlBuilder(card);
  modal.classList.remove("hidden");
}
function closeModal() {
  $("#modal").classList.add("hidden");
}
$("#modalBackdrop").onclick = closeModal;

function openCreatePlaylist() {
  if (!state.user) {
    toast("Inicia sesión para crear playlists");
    return;
  }
  openModal((card) => {
    card.appendChild(el("div", "modal-title", "Nueva playlist"));
    const input = el("input", "field");
    input.placeholder = "Nombre de la playlist";
    input.maxLength = 60;
    card.appendChild(input);
    const actions = el("div", "modal-actions");
    const cancel = el("button", "btn btn-ghost", "Cancelar");
    cancel.onclick = closeModal;
    const create = el("button", "btn btn-primary", "Crear");
    const submit = async () => {
      const name = input.value.trim();
      if (!name) return;
      await createPlaylist(name);
      closeModal();
    };
    create.onclick = submit;
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.nativeEvent?.isComposing && e.keyCode !== 229) submit();
    });
    actions.appendChild(cancel);
    actions.appendChild(create);
    card.appendChild(actions);
    setTimeout(() => input.focus(), 50);
  });
}

function openPlaylistPicker(track) {
  if (!state.user) {
    toast("Inicia sesión para usar playlists");
    return;
  }
  openModal((card) => {
    card.appendChild(el("div", "modal-title", "Añadir a playlist"));
    const list = el("div", "pl-pick-list");

    const createNew = el("button", "pl-pick");
    createNew.innerHTML = `<span style="width:40px;height:40px;border-radius:6px;background:var(--surface-2);display:grid;place-items:center"><svg viewBox="0 0 24 24" class="ic"><path d="M12 5v14"/><path d="M5 12h14"/></svg></span><span>Crear nueva playlist</span>`;
    createNew.onclick = async () => {
      const name = prompt("Nombre de la nueva playlist:");
      if (name && name.trim()) {
        const id = await createPlaylist(name.trim());
        if (id) await addTrackToPlaylist(id, track);
      }
      closeModal();
    };
    list.appendChild(createNew);

    const ids = Object.keys(state.playlists);
    ids.forEach((id) => {
      const pl = state.playlists[id];
      const b = el("button", "pl-pick");
      const img = el("img");
      img.src = pl.cover || ALBUM_PH;
      img.alt = "";
      b.appendChild(img);
      b.appendChild(el("span", null, escapeHtml(pl.name || "Playlist")));
      b.onclick = async () => {
        await addTrackToPlaylist(id, track);
        closeModal();
      };
      list.appendChild(b);
    });
    card.appendChild(list);

    const actions = el("div", "modal-actions");
    const cancel = el("button", "btn btn-ghost", "Cerrar");
    cancel.onclick = closeModal;
    actions.appendChild(cancel);
    card.appendChild(actions);
  });
}

/* ============================================================
   Full player expand / collapse
   ============================================================ */
function openFullPlayer() {
  if (!state.current) return;
  $("#fullPlayer").classList.remove("hidden");
  renderFullQueue();
}
function closeFullPlayer() {
  $("#fullPlayer").classList.add("hidden");
}

$("#mpExpandTrigger").addEventListener("click", (e) => {
  // Don't expand when clicking the control buttons
  if (e.target.closest(".mp-controls")) return;
  openFullPlayer();
});
$("#fpClose").onclick = closeFullPlayer;

/* ============================================================
   Wire up controls
   ============================================================ */
$("#mpPlay").onclick = (e) => { e.stopPropagation(); togglePlay(); };
$("#mpNext").onclick = (e) => { e.stopPropagation(); nextTrack(); };
$("#mpPrev").onclick = (e) => { e.stopPropagation(); prevTrack(); };
$("#fpPlay").onclick = togglePlay;
$("#fpNext").onclick = nextTrack;
$("#fpPrev").onclick = prevTrack;
$("#fpShuffle").onclick = () => {
  if (state.queue.length < 3) return;
  const rest = state.queue.slice(state.queueIndex + 1);
  for (let i = rest.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [rest[i], rest[j]] = [rest[j], rest[i]];
  }
  state.queue = [...state.queue.slice(0, state.queueIndex + 1), ...rest];
  renderFullQueue();
  preloadNext();
  toast("Cola aleatoria");
};
$("#fpAdd").onclick = () => {
  if (state.current) openPlaylistPicker(state.current);
};

const seek = $("#fpSeek");
seek.addEventListener("input", () => {
  seek.dragging = true;
});
seek.addEventListener("change", () => {
  if (audio.duration) audio.currentTime = (seek.value / 100) * audio.duration;
  seek.dragging = false;
});

$("#newPlaylistSide").onclick = openCreatePlaylist;

/* Search input */
const searchInput = $("#searchInput");
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  const q = searchInput.value.trim();
  searchTimer = setTimeout(() => {
    if (q) location.hash = `#/search/${encodeURIComponent(q)}`;
  }, 450);
});
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.nativeEvent?.isComposing && e.keyCode !== 229) {
    clearTimeout(searchTimer);
    const q = searchInput.value.trim();
    if (q) location.hash = `#/search/${encodeURIComponent(q)}`;
  }
});

/* Keep search box synced when navigating to a search route */
window.addEventListener("hashchange", () => {
  const hash = location.hash || "#/home";
  const [path, param] = hash.replace(/^#\//, "").split("/");
  if (path === "search" && param) {
    const decoded = decodeURIComponent(param);
    if (searchInput.value !== decoded) searchInput.value = decoded;
  }
  router();
});

/* ============================================================
   Init
   ============================================================ */
function init() {
  updatePlayButtons();
  initAuth();
  if (!location.hash) location.hash = "#/home";
  router();
  if (!firebaseReady) {
    setTimeout(
      () => toast("Configura Firebase en firebase-config.js para login y playlists"),
      800
    );
  }
}

init();
